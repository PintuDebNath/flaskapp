import os
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import numpy as np
import pandas as pd
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

import pandas as pd
import cv2
from PIL import Image
import scipy
import tensorflow as tf

import sys

# Load the images
import matplotlib.pyplot as plt

from tensorflow.keras.applications import *
from tensorflow.keras.optimizers import *
from tensorflow.keras.losses import *
from tensorflow.keras.layers import *
from tensorflow.keras.models import *
from tensorflow.keras.callbacks import *
from tensorflow.keras.preprocessing.image import *
from tensorflow.keras.utils import *
from sklearn.neural_network import MLPClassifier
import pydot
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import *
from sklearn import metrics
from sklearn.model_selection import *
import tensorflow.keras.backend as K
from tqdm import tqdm, tqdm_notebook
from colorama import Fore
import json
import matplotlib.pyplot as plt
import seaborn as sns
from glob import glob
from skimage.io import *
import time
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.svm import OneClassSVM
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import lightgbm as lgb
from xgboost import XGBClassifier
from sklearn.ensemble import AdaBoostClassifier,RandomForestClassifier

from sklearn.metrics import confusion_matrix
from sklearn.pipeline import make_pipeline
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline
from sklearn import pipeline
from sklearn.pipeline import Pipeline
import pickle
app = Flask(__name__)

# Define the path where you want to save files
UPLOAD_FOLDER = os.path.abspath('uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
@app.route('/')
def hello_world():
    return "This is Python App"
@app.route('/upload', methods=['POST'])
def upload_file():
    # Check if the request has the file part
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in the request'}), 400

    file = request.files['file']

    # If the user does not select a file, the browser submits an
    # empty file without a filename.
    if file.filename == '':
        return jsonify({'message': 'No selected file'}), 400

    if file:
        # Secure the filename before saving it
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        D = int
        print("Diabetic Positive")
        if (D == 0):
            exit()
        else:
            info = pd.read_csv('./content/File.csv')
        info.level.value_counts()
        sns.set_style('darkgrid')
        fig, ax = plt.subplots(figsize=(5, 5))
        sns.barplot(x=info.level.unique(), y=info.level.value_counts(), ax=ax)
        sizes = info['level'].values
        sns.distplot(sizes, kde=False)
        # List of image file paths
        image_paths = ["./content/1.png", "./content/2.png", "./content/3.png", "./content/4.jpg", "./content/5.jpg",
                       "./content/7.jpg"]

        # Initialize an empty list to store the loaded images
        images = []

        # Loop through the image paths and load each image
        for path in image_paths:
            img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
            if img is not None:
                images.append(img)
            else:
                print(f"Failed to load image from path: {path}")

        print(len(images))

        # Check if any images were loaded
        if len(images) > 0:
            for i in range(len(images)):
                desired_shape = (1000, images[i].shape[0], images[i].shape[1], 3)

                # Resize the image to match the desired shape
                resized_image = cv2.resize(images[i], (desired_shape[2], desired_shape[1]))

                # Repeat the resized image to match the desired number of frames
                reshaped_image = np.repeat(resized_image[np.newaxis, ...], desired_shape[0], axis=0)
                y = info['level'].values

        else:
            print("No images were loaded.")

        print(y.shape)
        # Display the loaded images

        for i, img in enumerate(images):
            # Convert BGR to RGB
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

            # Create a new figure for each image
            plt.figure()
            plt.imshow(img_rgb)
            plt.axis('off')
            plt.title(f"Training Image {i + 1}")

        # plt.show()

        print(y)

        y = np.resize(y, (1000,))  # Resize the array to have a shape of (100,)
        print(y.shape)

        X = np.array(reshaped_image)
        Y = np.array(y)
        # Y=to_categorical(Y,5)
        x_train, x_test1, y_train, y_test1 = train_test_split(X, Y, test_size=0.4, random_state=42)
        x_val, x_test, y_val, y_test = train_test_split(x_test1, y_test1, test_size=0.5, random_state=42)
        print(len(x_train), len(x_val), len(x_test))
        print(y_train)

        Y1 = pd.DataFrame(Y)
        Y1.value_counts()
        dnn_model = Sequential()
        dnn_model.add(Dense(8, input_dim=3, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(16, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(32, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(64, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(128, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(256, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(128, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(64, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(32, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(16, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(3, activation='softmax'))
        dnn_model.summary()

        from sklearn.pipeline import make_pipeline
        from sklearn.pipeline import Pipeline
        names = [
            "K Nearest Neighbour Classifier",
            'SVM',
            "Random Forest Classifier",
            "AdaBoost Classifier",
            "XGB Classifier",
            "MLP Classifier"
        ]
        classifiers = [
            KNeighborsClassifier(n_neighbors=5, algorithm='ball_tree', leaf_size=30),
            SVC(),
            RandomForestClassifier(max_depth=9, criterion='entropy'),
            AdaBoostClassifier(),
            XGBClassifier(),
            MLPClassifier()
        ]
        zipped_clf = zip(names, classifiers)

        def classifier_summary(pipeline, X_train, y_train, X_val, y_val, X_test, y_test):
            sentiment_fit = pipeline.fit(X_train, y_train)

            y_pred_train = sentiment_fit.predict(X_train)
            y_pred_val = sentiment_fit.predict(X_val)
            y_pred_test = sentiment_fit.predict(X_test)

            y_pred_train = [1 if x > 0.5 else 0 for x in y_pred_train]
            y_pred_val = [1 if x > 0.5 else 0 for x in y_pred_val]
            y_pred_test = [1 if x > 0.5 else 0 for x in y_pred_test]

            train_accuracy = np.round(accuracy_score(y_train, y_pred_train), 4) * 100
            train_precision = np.round(precision_score(y_train, y_pred_train, average='weighted'), 4)
            train_recall = np.round(recall_score(y_train, y_pred_train, average='weighted'), 4)
            train_F1 = np.round(f1_score(y_train, y_pred_train, average='weighted'), 4)
            train_kappa = np.round(cohen_kappa_score(y_train, y_pred_train), 4)

            val_accuracy = np.round(accuracy_score(y_val, y_pred_val), 4) * 100
            val_precision = np.round(precision_score(y_val, y_pred_val, average='weighted'), 4)
            val_recall = np.round(recall_score(y_val, y_pred_val, average='weighted'), 4)
            val_F1 = np.round(f1_score(y_val, y_pred_val, average='weighted'), 4)
            val_kappa = np.round(cohen_kappa_score(y_val, y_pred_val), 4)

            test_accuracy = np.round(accuracy_score(y_test, y_pred_test), 4) * 100
            test_precision = np.round(precision_score(y_test, y_pred_test, average='weighted'), 2)
            test_recall = np.round(recall_score(y_test, y_pred_test, average='weighted'), 2)
            test_F1 = np.round(f1_score(y_test, y_pred_test, average='weighted'), 2)
            test_kappa = np.round(cohen_kappa_score(y_test, y_pred_test), 2)

            print()
            print('------------------------ Train Set Metrics------------------------')
            print()
            print("Accuracy core : {}%".format(train_accuracy))

            print('------------------------ Validation Set Metrics------------------------')
            print()
            print("Accuracy score : {}%".format(val_accuracy))

            print('------------------------ Test Set Metrics------------------------')
            print()
            print("Accuracy score : {}%".format(test_accuracy))
            print("F1_score : {}".format(test_F1))
            print("Kappa Score : {} ".format(test_kappa))
            print("Recall score: {}".format(test_recall))
            print("Precision score : {}".format(test_precision))

            print("-" * 80)
            print()

        def classifier_comparator(X_train, y_train, X_val, y_val, X_test, y_test, classifier=zipped_clf):
            result = []
            for n, c in classifier:
                checker_pipeline = Pipeline([('Classifier', c)])
                print(
                    "------------------------------Fitting {} on input_data-------------------------------- ".format(n))
                # print(c)
                classifier_summary(checker_pipeline, X_train, y_train, X_val, y_val, X_test, y_test)

        base_model = ResNet50(input_shape=(images[i].shape[0], images[i].shape[1], 3), weights='imagenet',
                              include_top=False)
        x = base_model.output
        x = Dropout(0.5)(x)
        x = Flatten()(x)
        x = BatchNormalization()(x)
        x = Dense(16, kernel_initializer='he_uniform')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
        x = Dropout(0.5)(x)
        x = Dense(32, kernel_initializer='he_uniform')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
        x = Dropout(0.5)(x)
        x = Dense(64, kernel_initializer='he_uniform')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
        x = Dropout(0.5)(x)
        x = Dense(128, kernel_initializer='he_uniform')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
        x = Dropout(0.5)(x)
        x = Dense(256, kernel_initializer='he_uniform')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
        x = Dropout(0.5)(x)
        predictions = Dense(3, activation='softmax')(x)

        model_feat = Model(inputs=base_model.input, outputs=predictions)

        train_features = model_feat.predict(x_train)
        val_features = model_feat.predict(x_val)
        test_features = model_feat.predict(x_test)
        y_train_categorical = to_categorical(y_train, 2)
        y_test_categorical = to_categorical(y_test, 2)

        dnn_model = Sequential()
        dnn_model.add(Dense(8, input_dim=train_features.shape[1], kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(16, kernel_initializer='uniform', activation='relu'))
        dnn_model.add(BatchNormalization())
        dnn_model.add(Dropout(0.2))
        dnn_model.add(Dense(2, activation='softmax'))

        dnn_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        history = dnn_model.fit(train_features, y_train_categorical,
                                validation_data=(test_features, y_test_categorical), epochs=15)

        y_train_pred = dnn_model.predict(train_features)
        y_test_pred = dnn_model.predict(test_features)

        y_train_pred = np.argmax(y_train_pred, axis=1)
        y_test_pred = np.argmax(y_test_pred, axis=1)

        train_accuracy = accuracy_score(y_train, y_train_pred)
        test_accuracy = accuracy_score(y_test, y_test_pred)

        train_precision = precision_score(y_train, y_train_pred, average='weighted')
        test_precision = precision_score(y_test, y_test_pred, average='weighted')

        train_recall = recall_score(y_train, y_train_pred, average='weighted')
        test_recall = recall_score(y_test, y_test_pred, average='weighted')

        train_f1 = f1_score(y_train, y_train_pred, average='weighted')
        test_f1 = f1_score(y_test, y_test_pred, average='weighted')

        train_kappa = cohen_kappa_score(y_train, y_train_pred)
        test_kappa = cohen_kappa_score(y_test, y_test_pred)

        print('Train Accuracy:', train_accuracy)
        print('Test Accuracy:', test_accuracy)
        print('Train Precision:', train_precision)
        print('Test Precision:', test_precision)
        print('Train Recall:', train_recall)
        print('Test Recall:', test_recall)
        print('Train F1 Score:', train_f1)
        print('Test F1 Score:', test_f1)
        print('Train Cohen\'s Kappa:', train_kappa)
        print('Test Cohen\'s Kappa:', test_kappa)

        from sklearn.pipeline import make_pipeline
        from sklearn import pipeline
        from sklearn.pipeline import Pipeline
        names = [
            "K Nearest Neighbour Classifier",
            'SVM',
            "Random Forest Classifier",
            "AdaBoost Classifier",
            "XGB Classifier",
            "MLP Classifier"
        ]
        classifiers = [
            KNeighborsClassifier(n_neighbors=5, algorithm='ball_tree', leaf_size=30),
            SVC(),
            RandomForestClassifier(max_depth=9, criterion='entropy'),
            AdaBoostClassifier(),
            XGBClassifier(),
            MLPClassifier()
        ]
        zipped_clf = zip(names, classifiers)

        def classifier_summary(pipeline, X_train, y_train, X_val, y_val, X_test, y_test):
            sentiment_fit = pipeline.fit(X_train, y_train)

            y_pred_train = sentiment_fit.predict(X_train)
            y_pred_val = sentiment_fit.predict(X_val)
            y_pred_test = sentiment_fit.predict(X_test)

            train_accuracy = np.round(accuracy_score(y_train, y_pred_train), 4) * 100
            train_precision = np.round(precision_score(y_train, y_pred_train, average='weighted'), 4)
            train_recall = np.round(recall_score(y_train, y_pred_train, average='weighted'), 4)
            train_F1 = np.round(f1_score(y_train, y_pred_train, average='weighted'), 4)
            train_kappa = np.round(cohen_kappa_score(y_train, y_pred_train), 4)

            val_accuracy = np.round(accuracy_score(y_val, y_pred_val), 4) * 100
            val_precision = np.round(precision_score(y_val, y_pred_val, average='weighted'), 4)
            val_recall = np.round(recall_score(y_val, y_pred_val, average='weighted'), 4)
            val_F1 = np.round(f1_score(y_val, y_pred_val, average='weighted'), 4)
            val_kappa = np.round(cohen_kappa_score(y_val, y_pred_val), 4)

            test_accuracy = np.round(accuracy_score(y_test, y_pred_test), 4) * 100
            test_precision = np.round(precision_score(y_test, y_pred_test, average='weighted'), 2)
            test_recall = np.round(recall_score(y_test, y_pred_test, average='weighted'), 2)
            test_F1 = np.round(f1_score(y_test, y_pred_test, average='weighted'), 2)
            test_kappa = np.round(cohen_kappa_score(y_test, y_pred_test), 2)

            print()
            print('------------------------ Train Set Metrics------------------------')
            print()
            print("Accuracy core : {}%".format(train_accuracy))

            print('------------------------ Validation Set Metrics------------------------')
            print()
            print("Accuracy score : {}%".format(val_accuracy))

            print('------------------------ Test Set Metrics------------------------')
            print("Accuracy score : {}%".format(test_accuracy))

            print()
            print("Accuracy score : {}%".format(test_accuracy))
            print("F1_score : {}".format(test_F1))
            print("Kappa Score : {} ".format(test_kappa))
            print("Recall score: {}".format(test_recall))
            print("Precision score : {}".format(test_precision))

            print("-" * 80)
            print()

        def classifier_comparator(X_train, y_train, X_val, y_val, X_test, y_test, classifier=zipped_clf):
            result = []
            for n, c in classifier:
                checker_pipeline = Pipeline([('Classifier', c)])
                print(
                    "------------------------------Fitting {} on input_data-------------------------------- ".format(n))
                # print(c)
                classifier_summary(checker_pipeline, X_train, y_train, X_val, y_val, X_test, y_test)

                print(train_features)

                classifier_comparator(train_features, y_train, val_features, y_val, test_features, y_test,
                                      classifier=zipped_clf)

        train_y = to_categorical(y_train, num_classes=2)
        val_y = to_categorical(y_val, num_classes=2)
        test_y = to_categorical(y_test, num_classes=2)

        # Modify the last layer of your model to have 3 output units
        predictions = Dense(3, activation='softmax')(x)

        # Re-compile the model
        dnn_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

        # Train the model
        history = dnn_model.fit(train_features, train_y, validation_data=(val_features, val_y), epochs=15)

        # Evaluate the model
        loss_value, accuracy = dnn_model.evaluate(train_features, train_y)
        print('Train accuracy:', accuracy)

        loss_value, accuracy = dnn_model.evaluate(val_features, val_y)
        print('Validation accuracy:', accuracy)

        loss_value, accuracy = dnn_model.evaluate(test_features, test_y)
        print('Test accuracy:', accuracy)

        knn = KNeighborsClassifier(n_neighbors=5, algorithm='ball_tree', leaf_size=30)
        knn.fit(train_features, y_train)
        actual = np.random.binomial(1, .9, size=1000)
        predicted = np.random.binomial(1, .9, size=1000)
        confusion_matrix = metrics.confusion_matrix(actual, predicted)
        cm_display = metrics.ConfusionMatrixDisplay(confusion_matrix=confusion_matrix,
                                                    display_labels=['Positive', 'Negative'])
        cm_display.plot()
        # plt.show()

        # saving the trained model
        import pickle

        # Assuming 'model' is your trained AI model
        model = dnn_model  # Your trained model

        # Save the model to a file
        with open('Training_Model.pkl', 'wb') as file:
            pickle.dump(model, file)

            # saving the trained model
        import pickle

        # Assuming 'model' is trained AI model
        model1 = model_feat  # trained model

        # Save the model to a file
        with open('Prediction_Model.pkl', 'wb') as file:
            pickle.dump(model1, file)

            # Loading the saved model

        with open('Prediction_Model.pkl', 'rb') as file:
            loaded_model = pickle.load(file)

        desired_shape = (1000, images[i].shape[0], images[i].shape[1], 3)

        # Load and preprocess the new image(s)
        new_image = cv2.imread("5.jpg", cv2.IMREAD_UNCHANGED)
        resized_image = cv2.resize(new_image, (desired_shape[2], desired_shape[1]))
        X_new = np.repeat(resized_image[np.newaxis, ...], 1, axis=0)

        # Convert BGR to RGB
        new_image_rgb = cv2.cvtColor(new_image, cv2.COLOR_BGR2RGB)

        plt.title("User Testing Image")
        plt.imshow(new_image_rgb)
        plt.axis('off')
        # plt.show()

        loaded_model = dnn_model

        # Extract features from the new image(s) using the feature extraction model
        new_features = model_feat.predict(X_new)
        print(new_features)

        # Make predictions using the trained prediction model
        predictions = loaded_model.predict(new_features)

        # Interpret the predictions
        predicted_classes = np.argmax(predictions, axis=1)

        # Assuming 0 represents "negative" and 1 represents "positive"
        if predicted_classes[0] == 0:
            print("The image indicates a negative result for diabetic retinopathy.")
        else:
            print("The image indicates a positive result for diabetic retinopathy.")

        new_features = model_feat.predict(X_new)
        predictions = loaded_model.predict(new_features)

        # making predictive model
        predicted_classes = np.argmax(predictions, axis=1)

        # Assuming 0 represents "negative" and 1 represents "positive"
        if predicted_classes[0] == 0:
            print("Diabetic Retinopathy Negative")
        else:
            print("Diabetic Retinopathy Positive.")

        # Define class thresholds
        thresholds = {
            'mild': 0.1,
            'moderate': 0.4,
            'severe': 0.7
        }

        # Get the class probabilities from the model's predictions
        class_probabilities = predictions[0]

        # Classify the image based on the defined thresholds
        if class_probabilities[0] < thresholds['mild']:
            classification = "Mild Diabetic Retinopathy"
        elif class_probabilities[0] < thresholds['moderate']:
            classification = "Moderate Diabetic Retinopathy"
        elif class_probabilities[0] < thresholds['severe']:
            classification = "Severe Diabetic Retinopathy"
        else:
            classification = "Very Severe Diabetic Retinopathy"

        if predicted_classes[0] != 0:
            status = True
            print(f"Diabetic Retinopathy Classification: {classification}")
            message = f"Diabetic Retinopathy Classification: {classification}"
        else:
            status = False
            message = f"Diabetic Negative"
            print("Diabetic Retinopathy Classification");
    
    return jsonify({'status':status,'message': message}), 200

if __name__ == "__main__":
    app.run(debug=True,host="0.0.0.0",port=5000)